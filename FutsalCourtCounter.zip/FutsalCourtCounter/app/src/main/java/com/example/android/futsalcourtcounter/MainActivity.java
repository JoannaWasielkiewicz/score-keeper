package com.example.android.futsalcourtcounter;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Tracks the score for Team 1
    int scoreTeam1 = 0;

    // Tracks the score for Team 2
    int scoreTeam2 = 0;

    // Tracks number of fouls for Team 1
    int foul1 = 0;

    // Tracks number of fouls for Team 2
    int foul2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the goal button is clicked.
     */
    public void addOneForTeam1(View view) {
        scoreTeam1 = scoreTeam1 + 1;
        displayScoreTeam1(scoreTeam1);
    }

    /**
     * This method is called when the back button is clicked.
     */
    public void backForTeam1(View view) {
        if (scoreTeam1 < 1) {
            // Exit this method early because there's nothing left to do
            return;
        }
        scoreTeam1 = scoreTeam1 - 1;
        displayScoreTeam1(scoreTeam1);
    }

    public void addOneForTeam2(View view) {
        scoreTeam2 = scoreTeam2 + 1;
        displayScoreTeam2(scoreTeam2);
    }

    /**
     * This method is called when the back button is clicked.
     */
    public void backForTeam2(View view) {
        if (scoreTeam2 < 1) {
            // Exit this method early because there's nothing left to do
            return;
        }
        scoreTeam2 = scoreTeam2 - 1;
        displayScoreTeam2(scoreTeam2);
    }

    /**
     * This method is called when the foul button is clicked.
     */
    public void addFoul1(View view) {
        foul1 = foul1 + 1;
        //Every subsequent foul above 5 fouls affects double penalty
        if (foul1 > 5) {
            TextView foul = (TextView) findViewById(R.id.foul_1);
            foul.setTextColor(0xFFFF0000); //this is red color
            // Show message as a toast
            Toast.makeText(this, getString(R.string.double_penalty), Toast.LENGTH_SHORT).show();
        }

        displayFoul1(foul1);
    }

    /**
     * This method is called when the back button is clicked.
     */
    public void backFoul1(View view) {
        if (foul1 < 1) {
            // Exit this method early because there's nothing left to do
            return;
        }
        foul1 = foul1 - 1;
        if (foul1 < 6) {
            TextView foul = (TextView) findViewById(R.id.foul_1);
            foul.setTextColor(0xFF000000); //this is black color
        }
        displayFoul1(foul1);
    }

    public void addFoul2(View view) {
        foul2 = foul2 + 1;
        //Every subsequent foul above 5 fouls affects double penalty
        if (foul2 > 5) {
            TextView foul = (TextView) findViewById(R.id.foul_2);
            foul.setTextColor(0xFFFF0000); //this is red color
            // Show message as a toast
            Toast.makeText(this, getString(R.string.double_penalty), Toast.LENGTH_SHORT).show();
        }
        displayFoul2(foul2);
    }

    /**
     * This method is called when the back button is clicked.
     */
    public void backFoul2(View view) {
        if (foul2 < 1) {
            // Exit this method early because there's nothing left to do
            return;
        }
        foul2 = foul2 - 1;
        if (foul2 < 6) {
            TextView foul = (TextView) findViewById(R.id.foul_2);
            foul.setTextColor(0xFF000000); //this is black color
        }
        displayFoul2(foul2);
    }

    /**
     * This method displays goal and foul value on the screen.
     */
    private void displayScoreTeam1(int number) {
        TextView team_1_score = (TextView) findViewById(R.id.team_1_score);
        team_1_score.setText("" + number);
    }

    private void displayScoreTeam2(int number) {
        TextView team_2_score = (TextView) findViewById(R.id.team_2_score);
        team_2_score.setText("" + number);
    }

    private void displayFoul1(int number) {
        TextView foul_1 = (TextView) findViewById(R.id.foul_1);
        foul_1.setText("" + number);
    }

    private void displayFoul2(int number) {
        TextView foul_2 = (TextView) findViewById(R.id.foul_2);
        foul_2.setText("" + number);
    }

    /**
     * Resets the score for both teams back to 0.
     */
    public void resetScore(View v) {
        scoreTeam1 = 0;
        scoreTeam2 = 0;
        foul1 = 0;
        TextView foul = (TextView) findViewById(R.id.foul_1);
        foul.setTextColor(0xFF000000); //this is black color
        foul2 = 0;
        TextView foulb = (TextView) findViewById(R.id.foul_2);
        foulb.setTextColor(0xFF000000); //this is black color
        EditText editText1 = (EditText) findViewById(R.id.team1);
        editText1.getText().clear();
        EditText editText2 = (EditText) findViewById(R.id.team2);
        editText2.getText().clear();
        displayScoreTeam1(scoreTeam1);
        displayScoreTeam2(scoreTeam2);
        displayFoul1(foul1);
        displayFoul2(foul2);
    }
}
